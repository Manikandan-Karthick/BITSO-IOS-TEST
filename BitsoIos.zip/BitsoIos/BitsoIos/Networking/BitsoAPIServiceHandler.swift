//
//  BitsoAPIServiceHandler.swift
//  BitsoIos
//
//  Created by Kushi Karthick on 05/05/19.
//  Copyright © 2019 manikandan thirunavukarasu. All rights reserved.
//

import Foundation
import SVProgressHUD


class BitsoAPIServiceHandler {
   
    //BITSO API URL CONSTANTS
    // currently we are using Ticker API to receive Books,Price and details
    let BITSO_TICKER_URL = "https://api.bitso.com/v3/ticker/"
    // currently we are not using the below mentioned books API, since its providing only Books names but Ticker API provides Books,Price and details, so i used Ticker API
    //  let BITSO_BOOKS_URL = "https://api.bitso.com/v3/available_books/"


    typealias JSONDictionary = [String: Any]
    typealias BookResult = ([Book]?, String) -> ()
    
    let defaultSession = URLSession(configuration: .default)
    var dataTask: URLSessionDataTask?
    var books: [Book] = []
    var errorMessage = ""
    
    //MARK: - Get Books from API

    func getBooks(completion: @escaping BookResult) {
        // Start display progress indicator while doing networking
        SVProgressHUD.show()
        
        dataTask?.cancel()
        // configure URLcomponents with Ticker API URL
        if var urlComponents = URLComponents(string: BITSO_TICKER_URL) {
            
            guard let url = urlComponents.url else { return }
            dataTask = defaultSession.dataTask(with: url) { data, response, error in
                defer { self.dataTask = nil }
                if let error = error {
                    self.errorMessage += "DataTask error: " + error.localizedDescription + "\n"
                    // Stop display progress indicator
                    SVProgressHUD.dismiss()
                } else if let data = data,
                    let response = response as? HTTPURLResponse,
                    response.statusCode == 200 {
                    // successfully received data from API
                    self.updateBookResults(data)
                    DispatchQueue.main.async {
                        completion(self.books, self.errorMessage)
                    }
                }
            }
            dataTask?.resume()
        }
    }
    
    // MARK: - JSON parsing with received data
    
    fileprivate func updateBookResults(_ data: Data) {
        var response: JSONDictionary?
        books.removeAll()
        
        // Parsing - JSON Seriaization
        do {
            response = try JSONSerialization.jsonObject(with: data, options: []) as? JSONDictionary
        } catch let parseError as NSError {
            errorMessage += "JSONSerialization error: \(parseError.localizedDescription)\n"
            return
        }
        // according to the API data available from "payload"
        guard let array = response!["payload"] as? [Any] else {
            errorMessage += "Dictionary does not contain results key\n"
            return
        }
        var index = 0
        // Loading books array
        for bookTempDictionary in array {
            if let bookDictionary = bookTempDictionary as? JSONDictionary,
                let book = bookDictionary["book"] as? String,
                let bid = bookDictionary["bid"] as? String,
                let ask = bookDictionary["ask"] as? String,
                let low = bookDictionary["low"] as? String,
                let high = bookDictionary["high"] as? String,
                let twentyFourHourVolume = bookDictionary["volume"] as? String,
                let lastTradedPrice = bookDictionary["last"] as? String {
                // load books array with Book objects
                books.append(Book(book: book, bid: bid, ask: ask, low: low, high: high, twentyFourHourVolume: twentyFourHourVolume, lastTradedPrice: lastTradedPrice))
                index += 1
            } else {
                errorMessage += "Problem parsing bookDictionary\n"
            }
        }
    }
    
}
