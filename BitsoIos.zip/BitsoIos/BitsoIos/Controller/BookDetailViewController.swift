//
//  BookDetailViewController.swift
//  BitsoIos
//
//  Created by Kushi Karthick on 05/05/19.
//  Copyright © 2019 manikandan thirunavukarasu. All rights reserved.
//

import UIKit

class BookDetailViewController: UIViewController {
    
    var bookDetails : Book!
    @IBOutlet weak var lastPriceLabel: UILabel!
    @IBOutlet weak var bidValueLabel: UILabel!
    @IBOutlet weak var bookName: UILabel!
    @IBOutlet weak var askValueLabel: UILabel!
    @IBOutlet weak var lowValueLabel: UILabel!
    @IBOutlet weak var highValueLabel: UILabel!
    @IBOutlet weak var spreadValue: UILabel!
    @IBOutlet weak var twentyFourHRLabel: UILabel!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        // according to selected Book object update the UI
        updateBookDetails()
    }
    
    // in this method we do updating the UI of BookDetailViewController
    func updateBookDetails()  {
        
        let selectedBookName = bookDetails?.book.replacingOccurrences(of: "_", with: "/").uppercased()
       
        // Set navigation bar title as current selected Book
        self.title = selectedBookName
        bookName.text = selectedBookName
        lastPriceLabel.text = "$ " + (bookDetails?.lastTradedPrice)!
        bidValueLabel.text = "$ " + (bookDetails?.bid)!
        askValueLabel.text = "$ " + (bookDetails?.ask)!
        lowValueLabel.text = "$ " + (bookDetails?.low)!
        highValueLabel.text = " $" + (bookDetails?.high)!
        
        let twentyFourHRString = bookDetails?.twentyFourHourVolume
        let twentyFourDouble = Double(twentyFourHRString!)
        twentyFourHRLabel.text = String(roundDownSpreadOrTwentyFourHourValue(twentyFourDouble!, toNearest: 0.01))
        
        // preparing bid and ask values to calculate Spread
        let bidValueString = bookDetails?.bid
        let bidDouble = Double(bidValueString!)
        let askValueString = bookDetails?.ask
        let askDouble = Double(askValueString!)
        spreadValue.text = getSpreadValue(bid: bidDouble!, ask: askDouble!)
    }
    
    // calculating Spread from ask and bid values
    func getSpreadValue(bid : Double, ask : Double) -> String {
        let spread = ((ask - bid) / ask) * 100
        return String(roundDownSpreadOrTwentyFourHourValue(spread, toNearest: 0.01)) + "%"
    }
    
    // here we do round down the spread value and 24 hour value  Ex:  from 0.123450000 to 0.12
    // this method performs the rounddown operation with decimal values by using Floor value approach, Ex: from 0.123450000 to 0.12
    // according to the requirement we can update this with String operation else we will continue with existing approach
    func roundDownSpreadOrTwentyFourHourValue(_ value: Double, toNearest: Double) -> Double {
        return floor(value / toNearest) * toNearest
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
}

