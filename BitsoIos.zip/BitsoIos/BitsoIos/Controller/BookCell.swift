//
//  BookCell.swift
//  BitsoIos
//
//  Created by Kushi Karthick on 06/05/19.
//  Copyright © 2019 manikandan thirunavukarasu. All rights reserved.
//

import UIKit

class BookCell: UITableViewCell {

    @IBOutlet weak var bookName: UILabel!
    @IBOutlet weak var lastPrice: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }
    
    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)
        
        // Configure the view for the selected state
    }
    
}

