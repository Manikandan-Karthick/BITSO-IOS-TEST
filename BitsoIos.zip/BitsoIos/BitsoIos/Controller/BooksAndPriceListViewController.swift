//
//  BooksAndPriceListViewController.swift
//  BitsoIos
//
//  Created by Kushi Karthick on 05/05/19.
//  Copyright © 2019 manikandan thirunavukarasu. All rights reserved.
//

import UIKit
import SVProgressHUD

class BooksAndPriceListViewController: UIViewController,UITableViewDataSource,UITableViewDelegate {

    // this booksTableView displays the list of Bitso crypto currencies and prices
    @IBOutlet weak var booksTableView: UITableView!
    private let refreshControl = UIRefreshControl()
    
    var books: [Book] = []
    
    // use this service hanldler to invoke to make network calls to Bitso API
    let bitsoService = BitsoAPIServiceHandler()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        // set Navigation bar title here
        self.title = "Bitso Crypto Currencies"
        
        //pull to refresh feature to booksTableView
        pullToRefreshBooksTableView()
        
        //load books from Bitso API
        loadBooks()
    }
    
    //MARK: - Load Books from API
    // This method invokes bitsoService class's getBooks method and receives books data
    func loadBooks () {
        bitsoService.getBooks () { results, errorMessage in
            if let bookResults = results {
                self.books = bookResults
                self.booksTableView.reloadData()
                SVProgressHUD.dismiss()
            }
            if !errorMessage.isEmpty {
                print("Search error: " + errorMessage)
            }
            SVProgressHUD.dismiss()
        }
        self.refreshControl.endRefreshing()
    }
    
    //MARK: - Pull to Refresh functionality methods
    func pullToRefreshBooksTableView() {
        booksTableView.refreshControl = refreshControl
        refreshControl.addTarget(self, action: #selector(refreshBooks(_:)), for: .valueChanged)
    }
    
    //Pull to refresh method
    @objc private func refreshBooks(_ sender: Any) {
        // Fetch new books data from API
        loadBooks()
    }
    
    //MARK: - Books TableView delegate methods

    public func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int{
        return self.books.count
    }
    
    //the method returning each cell of the list
    public func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell{
        let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! BookCell
        let currentBook: Book
        currentBook = books[indexPath.row]
        let thisBookName = currentBook.book.replacingOccurrences(of: "_", with: "/").uppercased()
        cell.bookName.text = thisBookName
        cell.lastPrice.text = "$ " + currentBook.lastTradedPrice
        return cell
    }
    
    // method to run when table view cell is tapped
    func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    }
    
    /*
     // MARK: - Navigation
     
     // In a storyboard-based application, you will often want to do a little preparation before navigation
     override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
     // Get the new view controller using segue.destination.
     // Pass the selected object to the new view controller.
     }
     */
    
    //MARK: - Segue
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "bookDetail" {
            if let indexPath = booksTableView.indexPathForSelectedRow {
                let bookDetail : Book
                bookDetail = books[indexPath.row]
                let bookDetailVC = segue.destination as! BookDetailViewController
                bookDetailVC.bookDetails = bookDetail
            }
        }
    }
    
}

