//
//  Book.swift
//  BitsoIos
//
//  Created by Kushi Karthick on 05/05/19.
//  Copyright © 2019 manikandan thirunavukarasu. All rights reserved.
//

import Foundation

class Book {
    // according to the Bitso API URL: "https://api.bitso.com/v3/ticker/
    // the following properties added according to Bitso API result
    
    let book: String
    let bid: String
    let ask: String
    let low: String
    let high: String
    let twentyFourHourVolume: String
    let lastTradedPrice: String
    
    init(book: String, bid: String, ask: String, low: String, high: String, twentyFourHourVolume: String, lastTradedPrice: String) {
        self.book = book
        self.bid = bid
        self.ask = ask
        self.low = low
        self.high = high
        self.twentyFourHourVolume = twentyFourHourVolume
        self.lastTradedPrice = lastTradedPrice
    }
}
