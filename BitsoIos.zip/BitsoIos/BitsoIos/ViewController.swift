//
//  ViewController.swift
//  BitsoIos
//
//  Created by Kushi Karthick on 05/05/19.
//  Copyright © 2019 manikandan thirunavukarasu. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }


}

